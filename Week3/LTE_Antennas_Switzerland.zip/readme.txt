Direkt-Downloads (.json-Format):
http://data.geo.admin.ch/ch.bakom.mobil-antennenstandorte-lte/data/ch.bakom.mobil-antennenstandorte-lte_de.json
http://data.geo.admin.ch/ch.bakom.mobil-antennenstandorte-lte/data/ch.bakom.mobil-antennenstandorte-lte_fr.json
http://data.geo.admin.ch/ch.bakom.mobil-antennenstandorte-lte/data/ch.bakom.mobil-antennenstandorte-lte_it.json
http://data.geo.admin.ch/ch.bakom.mobil-antennenstandorte-lte/data/ch.bakom.mobil-antennenstandorte-lte_en.json
http://data.geo.admin.ch/ch.bakom.mobil-antennenstandorte-lte/data/ch.bakom.mobil-antennenstandorte-lte_rm.json